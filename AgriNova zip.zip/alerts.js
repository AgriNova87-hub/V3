/* =====================================================
   AgriNova Smart Alerts
   =====================================================

   CURRENT:
   Uses local sample farm data.

   FUTURE:
   These values can come from ESP32 / Firebase.

===================================================== */


/* =====================================================
   FARM DATA
===================================================== */

const farmData = {

  soilMoisture: 35,

  moistureThreshold: 40,

  temperature: 29,

  humidity: 65,

  motorStatus: "OFF",

  mode: "AUTO",

  rainDetected: false

};


/* =====================================================
   PAGE ELEMENTS
===================================================== */

const alertsContainer =
  document.getElementById("alertsContainer");

const allGood =
  document.getElementById("allGood");

const totalAlerts =
  document.getElementById("totalAlerts");

const criticalAlerts =
  document.getElementById("criticalAlerts");

const warningAlerts =
  document.getElementById("warningAlerts");

const refreshButton =
  document.getElementById("refreshButton");


/* =====================================================
   CREATE ALERTS
===================================================== */

function createAlerts() {

  const alerts = [];


  /* -----------------------------------------------
     SOIL MOISTURE — CRITICAL
  ------------------------------------------------ */

  if (farmData.soilMoisture < 20) {

    alerts.push({

      type: "critical",

      icon: "🚨",

      label: "CRITICAL",

      title: "Soil Moisture Critically Low",

      message:
        `Soil moisture is currently ` +
        `${farmData.soilMoisture}%. ` +
        `This is well below your selected ` +
        `${farmData.moistureThreshold}% threshold.`,

      details: [
        `Moisture: ${farmData.soilMoisture}%`,
        `Threshold: ${farmData.moistureThreshold}%`
      ],

      action: "Open Irrigation",

      link: "irrigation.html"

    });

  }


  /* -----------------------------------------------
     SOIL MOISTURE — WARNING
  ------------------------------------------------ */

  else if (
    farmData.soilMoisture <
    farmData.moistureThreshold
  ) {

    alerts.push({

      type: "warning",

      icon: "🌱",

      label: "IRRIGATION WARNING",

      title: "Soil Moisture Is Low",

      message:
        `Soil moisture has fallen to ` +
        `${farmData.soilMoisture}%, below your ` +
        `${farmData.moistureThreshold}% threshold.`,

      details: [
        `Moisture: ${farmData.soilMoisture}%`,
        `Threshold: ${farmData.moistureThreshold}%`
      ],

      action: "Open Irrigation",

      link: "irrigation.html"

    });

  }


  /* -----------------------------------------------
     HIGH TEMPERATURE
  ------------------------------------------------ */

  if (farmData.temperature >= 35) {

    alerts.push({

      type: "critical",

      icon: "🌡️",

      label: "TEMPERATURE ALERT",

      title: "Temperature Is High",

      message:
        `The current temperature is ` +
        `${farmData.temperature}°C. ` +
        `Monitor crop and soil conditions carefully.`,

      details: [
        `Temperature: ${farmData.temperature}°C`
      ],

      action: "View Weather",

      link: "weather.html"

    });

  }

  else if (farmData.temperature >= 32) {

    alerts.push({

      type: "warning",

      icon: "🌡️",

      label: "WEATHER WARNING",

      title: "Temperature Is Rising",

      message:
        `The current temperature is ` +
        `${farmData.temperature}°C. ` +
        `Keep monitoring the farm environment.`,

      details: [
        `Temperature: ${farmData.temperature}°C`
      ],

      action: "View Weather",

      link: "weather.html"

    });

  }


  /* -----------------------------------------------
     RAIN
  ------------------------------------------------ */

  if (farmData.rainDetected === true) {

    alerts.push({

      type: "weather",

      icon: "🌧️",

      label: "WEATHER ALERT",

      title: "Rain Detected",

      message:
        "Rain has been detected. " +
        "Consider delaying irrigation " +
        "to avoid unnecessary watering.",

      details: [
        "Rain detected"
      ],

      action: "View Weather",

      link: "weather.html"

    });

  }


  /* -----------------------------------------------
     HIGH HUMIDITY
  ------------------------------------------------ */

  if (farmData.humidity >= 85) {

    alerts.push({

      type: "warning",

      icon: "💧",

      label: "HUMIDITY WARNING",

      title: "Humidity Is High",

      message:
        `Humidity is currently ${farmData.humidity}%. ` +
        `Monitor the crop environment.`,

      details: [
        `Humidity: ${farmData.humidity}%`
      ],

      action: "Open Dashboard",

      link: "dashboard.html"

    });

  }


  /* -----------------------------------------------
     AUTO IRRIGATION
  ------------------------------------------------ */

  if (
    farmData.mode === "AUTO" &&
    farmData.soilMoisture <
      farmData.moistureThreshold &&
    farmData.motorStatus === "OFF" &&
    farmData.rainDetected === false
  ) {

    alerts.push({

      type: "warning",

      icon: "⚙️",

      label: "IRRIGATION",

      title: "Irrigation May Be Required",

      message:
        "AUTO mode has detected that soil moisture " +
        "is below the selected threshold while " +
        "the motor is currently OFF.",

      details: [
        `Mode: ${farmData.mode}`,
        `Motor: ${farmData.motorStatus}`
      ],

      action: "Open Dashboard",

      link: "dashboard.html"

    });

  }


  return alerts;

}


/* =====================================================
   DISPLAY ALERTS
===================================================== */

function displayAlerts() {

  const alerts = createAlerts();


  /* Counters */

  totalAlerts.textContent =
    alerts.length;


  criticalAlerts.textContent =
    alerts.filter(
      alert => alert.type === "critical"
    ).length;


  warningAlerts.textContent =
    alerts.filter(
      alert =>
        alert.type === "warning" ||
        alert.type === "weather"
    ).length;


  /* -----------------------------------------------
     NO ALERTS
  ------------------------------------------------ */

  if (alerts.length === 0) {

    alertsContainer.innerHTML = "";

    allGood.style.display = "block";

    return;

  }


  allGood.style.display = "none";


  /* -----------------------------------------------
     ALERT CARDS
  ------------------------------------------------ */

  alertsContainer.innerHTML =
    alerts.map(alert => {

      const details =
        alert.details
          .map(detail => `
            <span class="detail">
              ${detail}
            </span>
          `)
          .join("");


      return `

        <article class="alert-card ${alert.type}">

          <div class="alert-icon">
            ${alert.icon}
          </div>


          <div class="alert-content">

            <div class="alert-label">
              ${alert.label}
            </div>


            <h2>
              ${alert.title}
            </h2>


            <p>
              ${alert.message}
            </p>


            <div class="alert-details">
              ${details}
            </div>


            <a
              class="alert-action"
              href="${alert.link}"
            >
              ${alert.action} →
            </a>

          </div>


          <div class="alert-time">
            Now
          </div>

        </article>

      `;

    })
    .join("");

}


/* =====================================================
   REFRESH
===================================================== */

refreshButton.addEventListener(
  "click",
  displayAlerts
);


/* =====================================================
   MOBILE NAVIGATION
===================================================== */

const menuToggle =
  document.getElementById("menuToggle");

const navLinks =
  document.getElementById("navLinks");


menuToggle.addEventListener(
  "click",
  () => {

    navLinks.classList.toggle("open");

  }
);


/* Close menu after navigation */

document
  .querySelectorAll(".nav-links a")
  .forEach(link => {

    link.addEventListener(
      "click",
      () => {

        navLinks.classList.remove("open");

      }
    );

  });


/* =====================================================
   START PAGE
===================================================== */

displayAlerts();


/* =====================================================
   FUTURE FIREBASE CONNECTION
=====================================================

   Later we can replace:

   farmData.soilMoisture

   farmData.temperature

   farmData.humidity

   farmData.motorStatus

   farmData.mode

   farmData.moistureThreshold

   farmData.rainDetected

   with Firebase values.

   Example:

   farmData.soilMoisture = firebaseValue;

   Then call:

   displayAlerts();

   No changes to the HTML design will be required.

===================================================== */